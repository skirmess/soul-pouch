
SoulPouch_localization = {}

SoulPouch_localization.enUS = {
	SOULPOUCH				= 'Soul Pouch';
	FELCLOTHBAG				= 'Felcloth Bag';
	COREFELCLOTHBAG				= 'Core Felcloth Bag';

	WARLOCK					= 'Warlock';
}

SoulPouch_localization.deDE = {
	SOULPOUCH				= 'Seelenbeutel';
	FELCLOTHBAG				= 'Teufelsstofftasche';
	COREFELCLOTHBAG				= 'Core Felcloth Bag';

	WARLOCK					= 'Hexenmeister';
}

SoulPouch_localization.frFR = {
}

SoulPouch_localization.koKR = {
}

SoulPouch_Constants = SoulPouch_localization[GetLocale()]
